from pathlib import Path
import json,hashlib,subprocess,urllib.request,urllib.error,concurrent.futures
r=Path(__file__).parent;p=r/'baseline/production';s=(p/'intellignce-support/widget-v9.js').read_text();a=s.index('function acceptResult(');f=s[a:s.index('\n',a)]
h="const calls=[];let done,session={pending:{}};const CHAT_KEY='fixture';const localStorage={removeItem(){}};const add=(...x)=>calls.push(x);"+f+"\nacceptResult({ok:true,status:'booked',booking:true,reference:'HADI-00000000-0000-4000-8000-000000000000',meetingStatus:'ready',meetUrl:'https://meet.google.com/aaa-bbbb-ccc'});console.log(JSON.stringify({acceptedWithoutCalendarEventId:!!done,displayText:calls[0][1]}));";(r/'client_booking_fixture.cjs').write_text(h)
x=subprocess.run(['node',str(r/'client_booking_fixture.cjs')],capture_output=True,text=True);(r/'evidence/client_fixture.json').write_text(json.dumps({'exit':x.returncode,'stdout':x.stdout,'stderr':x.stderr},indent=2))
checks=[]
for f in p.rglob('*.js'):
 c=subprocess.run(['node','--check',str(f)],capture_output=True,text=True);checks.append({'path':str(f.relative_to(p)),'exit':c.returncode})
(r/'evidence/resumed_syntax.json').write_text(json.dumps(checks,indent=2))
def fetch(path):
 try:
  with urllib.request.urlopen(urllib.request.Request('https://hadi.intellignce.net'+path,headers={'Cache-Control':'no-cache'}),timeout=20) as x:b=x.read();status=x.status;headers={k.lower():v for k,v in x.headers.items()}
 except urllib.error.HTTPError as e:b=e.read();status=e.code;headers={k.lower():v for k,v in e.headers.items()}
 except Exception as e:return {'path':path,'error':str(e)}
 d={'path':path,'status':status,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'headers':headers}
 if path.endswith('.php'):
  try:d['health']=json.loads(b)
  except:pass
 if path=='/':
  import re;d['meta']=re.findall(r'<(?:meta|link)[^>]*(?:og:|twitter:|canonical|icon)[^>]*>',b.decode())
 return d
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:d=list(ex.map(fetch,['/','/api/leads.php','/intellignce-support/ask.php','/assets/hadi-hassan-social-preview-20261021.png','/favicon.ico']))
(r/'evidence/resumed_http.json').write_text(json.dumps(d,indent=2));print(json.dumps({'fixture':json.loads(x.stdout),'syntax':checks,'http':[{'path':v['path'],'status':v.get('status'),'error':v.get('error'),'health':v.get('health')} for v in d]},indent=2))
